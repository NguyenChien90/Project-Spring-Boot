package com.rk.exception;

public class WareHouseException extends Throwable {
    public WareHouseException(String s) {
       super(s);
    }
}
