package com.rk.exception;

public class CustomException extends Throwable {
    public CustomException(String message) {
        super(message);
    }
}
