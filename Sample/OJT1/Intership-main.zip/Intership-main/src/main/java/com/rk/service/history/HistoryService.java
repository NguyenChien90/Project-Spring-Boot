package com.rk.service.history;


import com.rk.model.History;

public interface HistoryService {
    void save(History history);
}
