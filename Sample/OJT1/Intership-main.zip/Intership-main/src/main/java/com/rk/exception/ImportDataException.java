package com.rk.exception;

public class ImportDataException extends Throwable {
    public ImportDataException(String s) {
        super(s);
    }
}
