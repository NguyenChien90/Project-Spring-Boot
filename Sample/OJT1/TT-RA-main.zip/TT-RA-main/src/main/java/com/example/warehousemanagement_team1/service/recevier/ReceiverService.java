package com.example.warehousemanagement_team1.service.recevier;

import com.example.warehousemanagement_team1.dto.request.ReceiverRequestDTO;

public interface ReceiverService {
    ReceiverRequestDTO save(ReceiverRequestDTO receiverDTO);
}
